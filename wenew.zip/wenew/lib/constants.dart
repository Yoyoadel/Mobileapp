
import 'package:flutter/material.dart';

class Constants {
  //Primary color
  static var primaryColor = const Color(0xff296e48);
  static var blackColor = Colors.black54;
  static const OPENWEATHER_API_KEY = "777658c0370d74b4c32a73f7d15de30f";
  static const NEWS_API_KEY = "2022ae8dadec4f09a63bb4255298d0f4";

  //Onboarding texts
  static var titleOne = "One App for Every Season, Every Story.";
  static var descriptionOne = " ";
  static var titleTwo = "See How Your Weather going";
  static var descriptionTwo = " ";
  static var titleThree = "Know What is Happening Around You";
  static var descriptionThree = "";
}