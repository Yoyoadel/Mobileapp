import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:wenew/Pages/Home_page.dart';
import 'package:wenew/Pages/login_page.dart'; // Assuming Login is the weather page

class newsPage extends StatefulWidget {
  const newsPage({super.key});

  @override
  State<newsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<newsPage> {
  List<dynamic> _articles = [];
  int _selectedIndex = 2; // Set News as the default selected index

  @override
  void initState() {
    super.initState();
    _fetchNews();
  }

  Future<void> _fetchNews() async {
    final response = await http.get(Uri.parse(
        'https://newsapi.org/v2/top-headlines?country=us&apiKey=2022ae8dadec4f09a63bb4255298d0f4'));

    if (response.statusCode == 200) {
      setState(() {
        _articles = json.decode(response.body)['articles'];
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to load news")),
      );
    }
  }

  void _onBottomNavTapped(int index) {
    if (index == 0) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomePage()),
      );
    } else if (index == 1) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Login()), // Navigate to Weather page
      );
    }
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/Images/nnn.jpg"), // Replace with your background path
                fit: BoxFit.cover,
              ),
            ),
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              title: const Text("Top Headlines"),
              backgroundColor: Colors.lightBlue.withOpacity(0.8),
            ),
            body: _articles.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
              padding: const EdgeInsets.all(8.0),
              itemCount: _articles.length,
              itemBuilder: (context, index) {
                var article = _articles[index];
                return NewsCard(article: article); // Using the custom widget
              },
            ),
            bottomNavigationBar: BottomNavigationBar(
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  label: 'Home',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.cloud),
                  label: 'Weather',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.article),
                  label: 'News',
                ),
              ],
              currentIndex: _selectedIndex,
              selectedItemColor: Colors.blue,
              onTap: _onBottomNavTapped,
            ),
          ),
        ],
      ),
    );
  }
}

// Custom widget for the news item card
class NewsCard extends StatelessWidget {
  final Map<String, dynamic> article;

  const NewsCard({Key? key, required this.article}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10.0),
      color: Colors.white.withOpacity(0.9),
      child: ListTile(
        contentPadding: const EdgeInsets.all(10.0),
        leading: article['urlToImage'] != null
            ? Image.network(
          article['urlToImage'],
          width: 80,
          height: 80,
          fit: BoxFit.cover,
        )
            : Container(
          width: 80,
          height: 80,
          color: Colors.grey[300],
          child: const Icon(Icons.image, color: Colors.grey),
        ),
        title: Text(
          article['title'] ?? 'No title available',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          article['description'] ?? 'No description available',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        onTap: () {
          // Open the article URL in a WebView or browser
        },
      ),
    );
  }
}
