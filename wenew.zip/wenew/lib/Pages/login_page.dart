import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:weather/weather.dart';
import 'package:wenew/Pages/Home_page.dart';
import 'NewsPage.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final WeatherFactory _wf = WeatherFactory("777658c0370d74b4c32a73f7d15de30f"); // Replace with your API key
  Weather? _weather;
  List<Weather>? _forecast;
  final TextEditingController _searchController = TextEditingController();
  int _selectedIndex = 1; // Default to Weather page

  @override
  void initState() {
    super.initState();
    _fetchWeather("Cairo"); // Default city on load
  }

  void _fetchWeather(String cityName) {
    _wf.currentWeatherByCityName(cityName).then((w) {
      setState(() {
        _weather = w;
      });
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("City not found")),
      );
    });

    _wf.fiveDayForecastByCityName(cityName).then((forecast) {
      setState(() {
        _forecast = forecast;
      });
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Unable to fetch forecast")),
      );
    });
  }

  void _onBottomNavTapped(int index) {
    if (index == 0) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HomePage()), // Navigate to Home
      );
    } else if (index == 2) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => newsPage()), // Navigate to News
      );
    }
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Using a Stack to layer the background image behind other elements
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/images/weather.jpeg"), // Background image path
                fit: BoxFit.cover,
              ),
            ),
          ),
          // AppBar and Weather content
          Scaffold(
            backgroundColor: Colors.transparent, // Make Scaffold transparent to show background
            appBar: AppBar(
              title: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Enter city name',
                  hintStyle: TextStyle(color: Colors.white60),
                  border: InputBorder.none,
                  suffixIcon: Icon(Icons.search, color: Colors.white),
                ),
                style: const TextStyle(color: Colors.white, fontSize: 18),
                onSubmitted: (value) {
                  if (value.isNotEmpty) {
                    _fetchWeather(value);
                  }
                },
              ),
              backgroundColor: Colors.lightBlue,
            ),
            body: _buildUI(context),
            bottomNavigationBar: BottomNavigationBar(
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  label: 'Home',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.cloud),
                  label: 'Weather',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.article),
                  label: 'News',
                ),
              ],
              currentIndex: _selectedIndex,
              selectedItemColor: Colors.blue,
              onTap: _onBottomNavTapped,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUI(BuildContext context) {
    if (_weather == null || _forecast == null) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        _dateTimeInfo(),
        _weatherIcon(),
        const SizedBox(height: 20), // Space between current weather and forecast
        _forecastWidget(),
      ],
    );
  }

  Widget _dateTimeInfo() {
    DateTime now = _weather!.date!;
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              DateFormat("EEEE").format(now),
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w900,
                color: Colors.white, // White text for readability
              ),
            ),
            Text(
              "  ${DateFormat("d.M.y").format(now)}",
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w300,
                color: Colors.white, // White text for readability
              ),
            ),
          ],
        ),
        Text(
          DateFormat("h:mm a").format(now),
          style: const TextStyle(
            fontSize: 18,
            color: Colors.blueAccent,
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  Widget _weatherIcon() {
    return Container(
      height: MediaQuery.of(context).size.height * 0.4,
      width: MediaQuery.of(context).size.width * 0.80,
      decoration: BoxDecoration(
        color: Colors.lightBlue.withOpacity(0.8), // Semi-transparent for better readability
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            _weather?.areaName ?? "",
            style: const TextStyle(
              fontSize: 60,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
          Container(
            height: MediaQuery.of(context).size.height * 0.13,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                    "http://openweathermap.org/img/wn/${_weather?.weatherIcon}@4x.png"),
              ),
            ),
          ),
          Text(
            _weather?.weatherDescription ?? "",
            style: const TextStyle(
              color: Colors.black,
              fontSize: 20,
            ),
          ),
          Text(
            "${_weather?.temperature?.celsius?.toStringAsFixed(0)}° C",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 35,
            ),
          ),
        ],
      ),
    );
  }

  Widget _forecastWidget() {
    return Column(
      children: [
        const Text(
          "5-Day Forecast",
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white, // White text for readability
          ),
        ),
        const SizedBox(height: 10),
        Container(
          height: 200, // Set height of forecast container
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _forecast?.length ?? 0,
            itemBuilder: (context, index) {
              var forecastDay = _forecast![index];
              DateTime forecastDate = forecastDay.date!;
              return Card(
                color: Colors.lightBlueAccent,
                margin: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Container(
                  width: 120,
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        DateFormat("d.M").format(forecastDate),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Image.network(
                        "http://openweathermap.org/img/wn/${forecastDay.weatherIcon}@4x.png",
                        width: 40,
                        height: 40,
                      ),
                      Text(
                        "${forecastDay.temperature?.celsius?.toStringAsFixed(0)}° C",
                        style: const TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        forecastDay.weatherDescription ?? "",
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
